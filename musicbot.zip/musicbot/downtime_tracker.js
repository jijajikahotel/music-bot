
const fs = require('fs');
const path = require('path');

class DowntimeTracker {
    constructor() {
        this.logFile = path.join(__dirname, 'downtime_logs.json');
        this.startTime = Date.now();
        this.ensureLogFile();
    }

    ensureLogFile() {
        if (!fs.existsSync(this.logFile)) {
            fs.writeFileSync(this.logFile, JSON.stringify({ logs: [] }, null, 2));
        }
    }

    getLogs() {
        try {
            const data = fs.readFileSync(this.logFile, 'utf8');
            return JSON.parse(data);
        } catch (error) {
            return { logs: [] };
        }
    }

    saveLogs(logs) {
        fs.writeFileSync(this.logFile, JSON.stringify(logs, null, 2));
    }

    logDowntime(reason = 'Unknown') {
        const logs = this.getLogs();
        const downtime = {
            id: Date.now(),
            downTime: new Date().toISOString(),
            reason: reason,
            upTime: null,
            duration: null
        };
        logs.logs.push(downtime);
        this.saveLogs(logs);
        return downtime.id;
    }

    logUptime(downtimeId) {
        const logs = this.getLogs();
        const downtimeLog = logs.logs.find(log => log.id === downtimeId);
        if (downtimeLog) {
            downtimeLog.upTime = new Date().toISOString();
            const downTime = new Date(downtimeLog.downTime);
            const upTime = new Date(downtimeLog.upTime);
            downtimeLog.duration = this.formatDuration(upTime - downTime);
            this.saveLogs(logs);
        }
    }

    formatDuration(ms) {
        const seconds = Math.floor(ms / 1000);
        const minutes = Math.floor(seconds / 60);
        const hours = Math.floor(minutes / 60);
        const days = Math.floor(hours / 24);

        if (days > 0) return `${days}d ${hours % 24}h ${minutes % 60}m`;
        if (hours > 0) return `${hours}h ${minutes % 60}m ${seconds % 60}s`;
        if (minutes > 0) return `${minutes}m ${seconds % 60}s`;
        return `${seconds}s`;
    }

    getRecentDowntimes(limit = 5) {
        const logs = this.getLogs();
        return logs.logs
            .sort((a, b) => new Date(b.downTime) - new Date(a.downTime))
            .slice(0, limit);
    }

    getCurrentUptime() {
        return this.formatDuration(Date.now() - this.startTime);
    }
}

module.exports = DowntimeTracker;
