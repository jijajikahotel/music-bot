const { Translate } = require('../../process_tools');
const { ActivityType } = require('discord.js');

module.exports = async (client) => {
    console.log(await Translate(`Logged to the client <${client.user.username}>.`));
    console.log(await Translate("Let's play some music !"));
    
    // Mark successful startup
    if (global.downtimeTracker) {
        const logs = global.downtimeTracker.getLogs();
        const lastLog = logs.logs[logs.logs.length - 1];
        if (lastLog && !lastLog.upTime) {
            global.downtimeTracker.logUptime(lastLog.id);
        }
    }
    
    client.user.setActivity(client.config.app.playing, { type: ActivityType.Watching });
}