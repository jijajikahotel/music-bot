
const { EmbedBuilder, ApplicationCommandOptionType } = require('discord.js');
const { Translate } = require('../../process_tools');

module.exports = {
    name: 'console',
    description: 'Show bot uptime and live status logs',
    
    async execute({ client, inter }) {
        const uptime = process.uptime();
        const hours = Math.floor(uptime / 3600);
        const minutes = Math.floor((uptime % 3600) / 60);
        const seconds = Math.floor(uptime % 60);
        
        const uptimeString = `${hours}h ${minutes}m ${seconds}s`;
        
        // Get memory usage
        const memUsage = process.memoryUsage();
        const memUsed = Math.round(memUsage.heapUsed / 1024 / 1024);
        const memTotal = Math.round(memUsage.heapTotal / 1024 / 1024);
        
        // Get current time
        const currentTime = new Date().toLocaleString();
        
        // Bot status info
        const guildCount = client.guilds.cache.size;
        const userCount = client.guilds.cache.reduce((acc, guild) => acc + guild.memberCount, 0);
        
        // Get downtime information
        const recentDowntimes = global.downtimeTracker ? global.downtimeTracker.getRecentDowntimes(3) : [];
        let downtimeText = '';
        
        if (recentDowntimes.length === 0) {
            downtimeText = '```✅ No recent downtimes recorded```';
        } else {
            downtimeText = '```';
            recentDowntimes.forEach((downtime, index) => {
                const downDate = new Date(downtime.downTime).toLocaleString();
                const upDate = downtime.upTime ? new Date(downtime.upTime).toLocaleString() : 'Still down';
                const duration = downtime.duration || 'Unknown';
                
                downtimeText += `${index + 1}. ${downDate}\n`;
                downtimeText += `   Reason: ${downtime.reason}\n`;
                downtimeText += `   Duration: ${duration}\n`;
                downtimeText += `   Up: ${upDate}\n\n`;
            });
            downtimeText += '```';
        }

        const embed = new EmbedBuilder()
            .setColor('#00ff00')
            .setTitle('🖥️ Bot Console & Live Status')
            .setAuthor({ 
                name: client.user.username, 
                iconURL: client.user.displayAvatarURL({ size: 1024, dynamic: true }) 
            })
            .addFields([
                {
                    name: '⏱️ Current Session Uptime',
                    value: `\`${uptimeString}\``,
                    inline: true
                },
                {
                    name: '💾 Memory Usage',
                    value: `\`${memUsed}MB / ${memTotal}MB\``,
                    inline: true
                },
                {
                    name: '🕐 Current Time',
                    value: `\`${currentTime}\``,
                    inline: true
                },
                {
                    name: '🌐 Servers',
                    value: `\`${guildCount}\``,
                    inline: true
                },
                {
                    name: '👥 Total Users',
                    value: `\`${userCount}\``,
                    inline: true
                },
                {
                    name: '📊 Status',
                    value: '🟢 **ONLINE**',
                    inline: true
                },
                {
                    name: '📝 Recent Logs',
                    value: '```' +
                           '✅ Web server running on port 3000\n' +
                           '✅ Discord Player loaded successfully\n' +
                           '✅ All commands loaded\n' +
                           '✅ Bot ready and operational\n' +
                           `✅ Last ping: ${Math.round(client.ws.ping)}ms` +
                           '```',
                    inline: false
                },
                {
                    name: '⬇️ Recent Downtime History',
                    value: downtimeText,
                    inline: false
                }
            ])
            .setFooter({ 
                text: await Translate('Console data refreshed'), 
                iconURL: inter.member.avatarURL({ dynamic: true }) 
            })
            .setTimestamp();

        await inter.editReply({ embeds: [embed] });
    }
};
