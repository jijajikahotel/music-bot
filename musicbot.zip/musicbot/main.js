const keep_alive = require('./keep_alive.js')
require("./server");
        
require('dotenv').config();

const { Player } = require('discord-player');
const { Client, GatewayIntentBits } = require('discord.js');
const { YoutubeiExtractor } = require('discord-player-youtubei'); // Import the new extractor
const DowntimeTracker = require('./downtime_tracker');

global.client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMembers,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.GuildVoiceStates,
        GatewayIntentBits.MessageContent,
    ],
    disableMentions: 'everyone',
});

// Initialize downtime tracker
global.downtimeTracker = new DowntimeTracker();

client.config = require('./config');

const player = new Player(client, client.config.opt.discordPlayer);
// Register the new Youtubei extractor
player.extractors.register(YoutubeiExtractor, {});

console.clear();
require('./loader');

client.login(client.config.app.token).catch(async (e) => {
    // Log downtime with reason
    global.downtimeTracker.logDowntime(e.message === 'An invalid token was provided.' ? 'Invalid Token' : 'Login Error');
    
    if (e.message === 'An invalid token was provided.') {
        require('./process_tools').throwConfigError('app', 'token', '\n\t   ❌ Invalid Token Provided! ❌ \n\tChange the token in the config file\n');
    } else {
        console.error('❌ An error occurred while trying to login to the bot! ❌ \n', e);
    }
});

// Handle process termination
process.on('SIGTERM', () => {
    global.downtimeTracker.logDowntime('Process Terminated');
    process.exit(0);
});

process.on('SIGINT', () => {
    global.downtimeTracker.logDowntime('Manual Shutdown');
    process.exit(0);
});

process.on('uncaughtException', (error) => {
    global.downtimeTracker.logDowntime(`Uncaught Exception: ${error.message}`);
    console.error('Uncaught Exception:', error);
    process.exit(1);
});

process.on('unhandledRejection', (reason) => {
    global.downtimeTracker.logDowntime(`Unhandled Rejection: ${reason}`);
    console.error('Unhandled Rejection:', reason);
});
